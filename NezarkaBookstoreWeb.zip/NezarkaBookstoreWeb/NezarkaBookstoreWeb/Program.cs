﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using JumpingPlatformGame;

namespace NezarkaBookstoreWeb {

    class Program {
        private static void Main(string[] args) {
            var reader = Console.In;

            var store = ModelStore.LoadFrom(reader);
            if (store == null) {
                Console.WriteLine("Data error.");
                return;
            }

            //TODO: Create GameControler in Nezarka, that will communicate with JumpingGameControler
            ConfigureJumpingGame(store);

            var masterController = new MasterController(
                store,
                new BooksController(
                    store,
                    new BooksViewFactory(),
                    new BooksDetailViewFactory()
                ),
                new ShoppingCartController(
                    store,
                    new ShoppingCartViewFactory()
                ),
                new MasterViewFactory(),
                new MenuViewFactory()
            );

            var writer = Console.Out;

            string line;
            while ((line = reader.ReadLine()) != null) {
                masterController.ExecuteRequest(line, writer);
                writer.WriteLine("====");
            }
        }

        private static void ConfigureJumpingGame(ModelStore store) {
            List<string> users = new List<string>();
            List<DateTime?> dates = new List<DateTime?>();
            int i = 1;

            while (true) {
                Customer customer = store.GetCustomer(i);

                if (customer == null) {
                    break;
                }

                string usersName = customer.FirstName + " " + customer.LastName;
                users.Add(usersName);
                dates.Add(customer.DateJoined);

                i++;
            }

            JumpingGameControler.Configure(users, dates);
        }
    }

}
