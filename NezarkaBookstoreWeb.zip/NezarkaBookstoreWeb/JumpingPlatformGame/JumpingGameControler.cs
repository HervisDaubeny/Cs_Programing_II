﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JumpingPlatformGame {
    public static class JumpingGameControler {
        public static void Configure(List<string> names, List<DateTime?> dates) {
            User[] users = new User[names.Count];

            for (int i = 0; i < names.Count; i++) {
                users[i] = new User(names[i], dates[i]);
            }

            Program.Users = users;
        }
        public static void BeginGame() {
            Program.BeginGame();
        }
    }
}
