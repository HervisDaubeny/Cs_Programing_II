﻿using System.Drawing;

namespace JumpingPlatformGame {
	class Entity {
		public virtual Color Color => Color.Black;
        public virtual void Update(Seconds time) { }
        public WorldPoint Location;
	}

	class MovableEntity : Entity {
        public Movement Horizontal { get; set; }
        public MovableEntity() {
            this.Horizontal = new Movement();
        }
        public override void Update(Seconds time) {
            if (Location.X <= Horizontal.LowerBound || Location.X >= Horizontal.UpperBound) {
                Horizontal.Speed *= -1;
            }
            Location.X += Horizontal.Speed * time;
        }
    }

	class MovableJumpingEntity : MovableEntity {
        public Movement Vertical { get; set; }

        public MovableJumpingEntity() : base() {
            this.Vertical = new Movement();
        }

        public override void Update(Seconds time) {
            if (Location.X <= Horizontal.LowerBound || Location.X >= Horizontal.UpperBound) {
                Horizontal.Speed *= -1;
            }
            Location.X += Horizontal.Speed * time;

            if (Location.Y >= Vertical.UpperBound) {
                Vertical.Speed *= -1;
            }
            else if (Location.Y == Vertical.LowerBound && Vertical.Speed < 0) {
                return;
            }
            else if (Location.Y < Vertical.LowerBound && Vertical.Speed < 0) {
                Location.Y = Vertical.LowerBound;
                return;
            }
            Location.Y += Vertical.Speed * time;
        }
    }

	class Joe : MovableEntity {
		public override string ToString() => "Joe";
		public override Color Color => Color.Blue;
	}

	class Jack : MovableEntity {
		public override string ToString() => "Jack";
		public override Color Color => Color.LightBlue;
	}

	class Jane : MovableJumpingEntity {
		public override string ToString() => "Jane";
		public override Color Color => Color.Red;
	}

	class Jill : MovableJumpingEntity {
		public override string ToString() => "Jill";
		public override Color Color => Color.Pink;
	}

    class User : MovableEntity {
        public string Name { get; set; }
        public System.DateTime? DateJoined { get; set; }
        public Color EntityColor { get; set; }

        public User(string Name, System.DateTime? DateJoined) {
            this.Name = Name;
            this.DateJoined = DateJoined;

            SetEntityColor();
        }

        public override Color Color => EntityColor;

        public override string ToString() => Name;

        private void SetEntityColor() {
            System.DateTime? today = System.DateTime.Now;
            System.DateTime? always = null;
            System.DateTime? year1 = today - System.TimeSpan.FromDays(365);
            System.DateTime? year2 = today - System.TimeSpan.FromDays(2 * 365);
            System.DateTime? year3 = today - System.TimeSpan.FromDays(3 * 365);
            System.DateTime? year4 = today - System.TimeSpan.FromDays(4 * 365);
            

            if (DateJoined == always) {
                EntityColor = Color.Gold;

                return;
            }

            if (DateJoined > year1) { //less then a year
                EntityColor = Color.Black;
            }
            else if (DateJoined <= year1 && DateJoined > year2) { //one and more
                EntityColor = Color.DarkRed;
            }
            else if (DateJoined <= year2 && DateJoined > year3) { //two and more
                EntityColor = Color.Red;
            }
            else if (DateJoined <= year3 && DateJoined > year4) { //three and more
                EntityColor = Color.IndianRed;
            }
            else if (DateJoined <= year4) { //four and more
                    EntityColor = Color.OrangeRed;
            }
        }
    }

    struct WorldPoint {
        public Meters X { get; set; }
        public Meters Y { get; set; }
    }

    class Movement {
        public Meters LowerBound { get; set; }
        public Meters UpperBound { get; set; }
        public MeterPerSeconds Speed { get; set; }
    }
}